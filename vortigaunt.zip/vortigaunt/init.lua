mobs:register_mob("vortigaunt:vortigaunt", {
type = "npc",
passive = true,
--rotate=270,
group_attack = true,
damage = 11,
attack_type = "dogfight",
hp_min = 30,
hp_max = 60,
armor = 100,
-- textures and model
collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
visual_size = {x = 0.4, y=0.4, z = 0.4},
visual = "mesh",
drawtype = "front",
mesh = "vortie.glb",
textures = {
{"vortie.png"},
{"vorteye.png","vortie.png"}
},
-- sounds
makes_footstep_sound = true,
sounds = {
random = "",
damage = "mobs_punch",
death = "mobs_stonemonster",
},
-- speed and jump
walk_velocity = 3,
run_velocity = 5,
jump = true,
-- damaged by
water_damage = 0,
lava_damage = 0,
light_damage = 0,
view_range = 39,
fear_height = 1,
animation = {
speed_normal = 30,
speed_run = 30,
stand_start = 0,
stand_end = 79,
walk_start = 168,
walk_end = 187,
run_start = 168,
run_end = 187,
punch_start = 200,
punch_end = 219,
},

follow = {
		"default:apple", "ugx:teleport_fruit", "farming:bread",
		"farming:bread_slice", "farming:corn"
	},

on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 20, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
	end
})

mobs:register_egg("vortigaunt:vortigaunt", ("Vortigaunt"), "vorteye.png", 1)

