mobs:register_mob("mob_shadow:shadow", {
	type = "npc",
	damage = 1,
	reach = 2,
	attack_type = "dogfight",
	suicidal=true,
	hp_min = 30,
	hp_max = 30,
	attacks_monsters=true,
	group_attack=true,
	owner_loyal=false,
	collisionbox = {-0.3, 0, -0.3, 0.3, 1.5, 0.3},
	visual = "mesh",
	mesh = "shadow.b3d",
	textures = {
		{"horror_shadow_elemental.png"},
	},
	blood_amount = 60,
	blood_texture = "smoke_puff.png",
	visual_size = {x=2, y=2},
	makes_footstep_sound = false,
	walk_velocity = 2,
	run_velocity = 4,
	walk_chance=99,
	jump = true,
	fly = true,
	fly_in={"air", "default:water_source", "default:river_water_source", "default:river_water_flowing"},
	floats = true,
	fall_speed = 0,
	regen=-0.5,
	view_range = 69,
	env_dmg={["maptools:smoke"]=0, ["default:ice"]=0, ["default:placeholder"]=-1},
	animation = {
		speed_normal = 5,
		speed_run = 6,
		walk_start = 2,
		walk_end = 19,
		stand_start = 2,
		stand_end = 19,
		run_start = 2,
		run_end = 19,
		punch_start = 2,
		punch_end = 19,
	},
})


minetest.register_tool(":basetools:useless", {
    description = "literlly uncanny sowrd",
    inventory_image = "theendsword.png^bl_sword.png",
    tool_capabilities = {
        full_punch_interval = 666.6,
        max_drop_level = 5,
        groupcaps = {
            snappy = {
                times = {[2] = 0.9, [3] = 0.4},
                uses = 20000,
                maxlevel = 5,
            },
        },
        damage_groups = {fleshy = 999999},
    },
    wield_scale = {x = 2, y = 2, z = 1},  -- Adjust the wield scale as needed
})


